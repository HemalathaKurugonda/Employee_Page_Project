package com.example.ope;

public @interface Controller {

}
